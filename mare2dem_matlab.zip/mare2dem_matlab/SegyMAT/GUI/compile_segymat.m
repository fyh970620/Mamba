mcc -B sgl segymat
