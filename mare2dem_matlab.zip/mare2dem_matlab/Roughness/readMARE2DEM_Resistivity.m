function  Resistivity = readMARE2DEM_Resistivity(file,bNoData)
%
%
%��ȡMARE2DEM *.resistivity�ļ�
%

%�����˽���ȡ���ö�����ȡ���ݵĿ�ѡ��������Щ�ļ��е�һЩ���÷ǳ����������Ҫ��ֻ��ͷ�ļ������������ø��졣
    if ~exist('bNoData','var') || isempty(bNoData)
        bNoData = false;
    elseif ischar(bNoData)
        bNoData = strncmpi( bNoData, 'n', 1 );  % �����ַ����������ݡ���
    end

    
    Resistivity = [];
    
    fid = fopen(file,'r');
    
    while ~ feof(fid)
        
     
        
        sLine = fgets( fid );
        [sCode, sValue] = strtok( sLine, ':' );
        sCode = lower(strtrim(sCode));
        if ~isempty(sValue)
         sValue(1) = [];    
        end
        % �����ֵ�а����û�ע�ͣ�����ɾ����
        sValue = strtrim( strtok(sValue, '!%') );
        
        % ������ʲô���룿
        switch (sCode)
            case {'format','version'}
                Resistivity.version = sValue;
            case {'model file'}
                Resistivity.modelFile = sValue;
            case {'data file'}
                Resistivity.dataFile = sValue;
            case {'settings file'}    
                Resistivity.settingsFile = sValue;
            case {'penalty file'}   
                Resistivity.penaltyFile = sValue;
            case {'maximum interations'}       
                Resistivity.maxIterations = sscanf(sValue,'%g',1);
            case {'bounds transform'}
                Resistivity.boundsTransform = sValue;
            case {'global bounds'}   
                ind = findstr(sValue,',');
                if ~isempty(ind) % �ÿո��滻����
                    sValue(ind) = ' ';
                end
                Resistivity.globalBounds = sscanf(sValue,'%g %g',2);
            case {'debug level','print level'}
                Resistivity.debugLevel = sscanf(sValue,'%i',1);
            case {'target misfit'}    
                Resistivity.targetMisfit = sscanf(sValue,'%g',1);
            case {'iteration'}  
                Resistivity.iteration = sscanf(sValue,'%i',1);
            case {'lagrange value'}     
                Resistivity.lagrange =  sscanf(sValue,'%g',1);
            case {'model roughness'}  
                Resistivity.roughness =  sscanf(sValue,'%g',1);
            case {'model misfit'}   
                Resistivity.misfit =  sscanf(sValue,'%g',1);
            case {'date/time'}
                Resistivity.dateAndTime =  sValue;
            case {'inversion method'}
                Resistivity.inversionMethod =  lower(sValue);  
            case {'fixed mu cut'}   
                Resistivity.fixedMuCut =  sscanf(sValue,'%g',1);     
            case {'converge slowly'}    
                Resistivity.convergeSlowly = lower(sValue); 
            case {'misfit decrease threshold'}    
                Resistivity.rmsThreshold = sscanf(sValue,'%g',1);            
            case {'anisotropy'} 
                Resistivity.anisotropy = sValue;
            case {'number of regions'}     
                if bNoData  % �������ݣ�û��ʲô���ڴ�֮�� ��������
                    break;
                end
                
                Resistivity.numRegions = sscanf(sValue,'%i',1);
               
                switch Resistivity.anisotropy
                    case 'isotropic'
                        nrho = 1;
                        str ='%g';
                    case 'triaxial'
                        nrho = 3;
                        str ='%g%g%g';
                    case {'tix', 'tiy', 'tiz'}
                        nrho = 2;   
                        str ='%g%g';
                end
                
                Resistivity.resistivity   = zeros(Resistivity.numRegions,nrho);
                Resistivity.freeparameter = zeros(Resistivity.numRegions,nrho);
                Resistivity.prejudice     = zeros(Resistivity.numRegions,2*nrho);
                Resistivity.bounds        = zeros(Resistivity.numRegions,2*nrho);
                Resistivity.ratioPrej     = zeros(Resistivity.numRegions,nrho*(nrho-1));
                
                sLine = fgets(fid); % һ��ע����
                
                if strcmpi(Resistivity.version,'MARE2DEM_1.0') || nrho == 1
                    scstr = sprintf('%s%s%s%s%s%s%s','%*i',str,str,str,str,str,str);
                elseif nrho == 2  % ��2�������Ӹ������Ա���Ȩ�غ���ѡ�
                    scstr = sprintf('%s%s%s%s%s%s%s%s','%*i',str,str,str,str,str,str,str);
                elseif nrho == 3 % ��3 x 2�������Ӹ������Ա�����ѡ�
                    scstr = sprintf('%s%s%s%s%s%s%s%s%s','%*i',str,str,str,str,str,str,str,str);
                end
                    
                for i = 1:Resistivity.numRegions
                     sLine = fgets(fid);       
                     vals = sscanf(sLine,scstr);
                     Resistivity.resistivity(i,1:nrho)   = vals(1:nrho);
                     Resistivity.freeparameter(i,1:nrho) = vals(nrho+[1:nrho]);
                     Resistivity.bounds(i,1:2*nrho)      = vals(2*nrho+[1:2*nrho]);
                     Resistivity.prejudice(i,1:2*nrho)   = vals(4*nrho+[1:2*nrho]);
                     if length(vals) > 6*nrho  % �����и������Ա�����ѡ����¸�ʽ
                        Resistivity.ratioPrej(i,1:nrho*(nrho-1)) = vals(6*nrho+1:end);
                     end
                end
                
            otherwise
              
            
        end
    end
    
   
    fclose(fid);
    
end